window.moment = require('moment');
require('../../node_modules/vis/dist/vis-timeline-graph2d.min.css');
module.exports = require('../../node_modules/vis/dist/vis-timeline-graph2d.min');
