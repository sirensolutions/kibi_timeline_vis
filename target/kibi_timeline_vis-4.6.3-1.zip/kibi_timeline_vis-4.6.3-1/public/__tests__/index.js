describe('Kibi Timeline', function () {
  require('./kibi_timeline');
  require('./_vis');
  require('./kibi_select');
  require('../lib/helpers/__tests__/timeline_helper');
});
