describe('Kibi Timeline', function () {
  require('./_vis');
});
