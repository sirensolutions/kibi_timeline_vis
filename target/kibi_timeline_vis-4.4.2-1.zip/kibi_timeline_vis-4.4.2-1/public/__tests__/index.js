describe('Kibi Timeline', function () {
  require('./_vis');
  require('./kibi_select');
  require('../lib/helpers/__tests__/timeline_helper');
});
