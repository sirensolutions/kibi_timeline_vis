require('bower_components/vis/dist/vis.min.css');
module.exports = require('bower_components/vis/dist/vis.min.js');
