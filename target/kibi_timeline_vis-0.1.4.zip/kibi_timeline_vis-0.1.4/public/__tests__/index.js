describe('Kibi Timeline', function () {
  require('./_vis');
  require('../lib/helpers/__tests__/timeline_helper');
});
