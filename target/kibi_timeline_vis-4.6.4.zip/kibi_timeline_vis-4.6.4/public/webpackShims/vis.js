require('../../node_modules/vis/dist/vis.min.css');
module.exports = require('../../node_modules/vis/dist/vis.js');
